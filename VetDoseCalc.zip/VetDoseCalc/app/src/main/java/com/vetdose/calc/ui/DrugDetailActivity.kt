package com.vetdose.calc.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.vetdose.calc.R
import com.vetdose.calc.data.DoseCalculator
import com.vetdose.calc.data.DoseCalculator.fmt
import com.vetdose.calc.data.DrugRepository
import com.vetdose.calc.databinding.ActivityDrugDetailBinding

class DrugDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDrugDetailBinding
    private lateinit var repo: DrugRepository
    private var drugId = ""
    private var weight = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDrugDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        repo = DrugRepository(this)
        drugId = intent.getStringExtra("drug_id") ?: ""
        weight = intent.getDoubleExtra("weight", 0.0)

        loadDrug()

        binding.etWeightDetail.setText(if (weight > 0) weight.toString() else "")
        binding.etWeightDetail.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                weight = s?.toString()?.toDoubleOrNull() ?: 0.0
                updateCalculation()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val drug = repo.getDrugById(drugId)
        if (drug?.isCustom == true) {
            menuInflater.inflate(R.menu.detail_menu, menu)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> { finish(); true }
            R.id.action_edit -> {
                val intent = Intent(this, AddEditDrugActivity::class.java)
                intent.putExtra("drug_id", drugId)
                startActivity(intent)
                true
            }
            R.id.action_delete -> {
                AlertDialog.Builder(this)
                    .setTitle("Delete Drug")
                    .setMessage("Delete this custom drug?")
                    .setPositiveButton("Delete") { _, _ ->
                        repo.deleteCustomDrug(drugId)
                        finish()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun loadDrug() {
        val drug = repo.getDrugById(drugId) ?: return
        supportActionBar?.title = drug.name

        binding.tvDetailCategory.text = drug.category
        binding.tvDetailSpecies.text = "Species: ${drug.species.joinToString(", ")}"
        binding.tvDetailRoute.text = "Route: ${drug.route}"
        binding.tvDetailFrequency.text = "Frequency: ${drug.frequency}"
        binding.tvDetailDoseRange.text = "Dose: ${drug.doseMin}–${drug.doseMax} ${drug.doseUnit}"
        binding.tvDetailConcentration.text =
            "Stock concentration: ${drug.concentration} ${drug.concentrationUnit}"
        if (drug.maxDose > 0) {
            binding.tvMaxDose.visibility = View.VISIBLE
            binding.tvMaxDose.text = "⚠️ Max absolute dose: ${drug.maxDose} ${drug.doseUnit.replace("/kg","")}"
        } else {
            binding.tvMaxDose.visibility = View.GONE
        }
        binding.tvDetailNotes.text = if (drug.notes.isNotBlank()) "📝 ${drug.notes}" else ""
        if (drug.warning.isNotBlank()) {
            binding.tvDetailWarning.visibility = View.VISIBLE
            binding.tvDetailWarning.text = "⚠️ WARNING: ${drug.warning}"
        } else {
            binding.tvDetailWarning.visibility = View.GONE
        }

        updateCalculation()
    }

    private fun updateCalculation() {
        val drug = repo.getDrugById(drugId) ?: return
        if (weight <= 0) {
            binding.cardResult.visibility = View.GONE
            return
        }
        binding.cardResult.visibility = View.VISIBLE

        val result = DoseCalculator.calculate(drug, weight)

        binding.tvResultWeight.text = "Patient weight: ${weight} kg"

        if (drug.doseMin == drug.doseMax) {
            binding.tvResultDose.text =
                "Dose: ${result.doseMinMg.fmt(3)} ${drug.doseUnit.replace("/kg","")}"
            binding.tvResultVolume.text =
                "Volume to give: ${result.volumeMin.fmt(2)} ml"
        } else {
            binding.tvResultDose.text =
                "Dose: ${result.doseMinMg.fmt(3)}–${result.doseMaxMg.fmt(3)} ${drug.doseUnit.replace("/kg","")}"
            binding.tvResultVolume.text =
                "Volume to give: ${result.volumeMin.fmt(2)}–${result.volumeMax.fmt(2)} ml"
        }

        if (result.isCapped) {
            binding.tvCappedWarning.visibility = View.VISIBLE
        } else {
            binding.tvCappedWarning.visibility = View.GONE
        }
    }
}
