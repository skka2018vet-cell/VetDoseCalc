package com.vetdose.calc.model

import com.google.gson.annotations.SerializedName

data class Drug(
    @SerializedName("id")                val id: String,
    @SerializedName("name")              val name: String,
    @SerializedName("category")          val category: String,
    @SerializedName("species")           val species: List<String>,
    @SerializedName("doseMin")           val doseMin: Double,
    @SerializedName("doseMax")           val doseMax: Double,
    @SerializedName("doseUnit")          val doseUnit: String,
    @SerializedName("route")             val route: String,
    @SerializedName("concentration")     val concentration: Double,
    @SerializedName("concentrationUnit") val concentrationUnit: String,
    @SerializedName("frequency")         val frequency: String,
    @SerializedName("notes")             val notes: String,
    @SerializedName("warning")           val warning: String,
    @SerializedName("maxDose")           val maxDose: Double = 0.0,
    @SerializedName("isCustom")          val isCustom: Boolean = false
)

data class DoseResult(
    val drug: Drug,
    val weight: Double,
    val species: String,
    val doseMinRaw: Double,
    val doseMaxRaw: Double,
    val volumeMin: Double,
    val volumeMax: Double,
    val isCapped: Boolean
)

// Species for Dog/Cat app
val ALL_SPECIES = listOf("Dog", "Cat")

// All drug categories in the database
val ALL_CATEGORIES = listOf(
    "Antibiotic",
    "Antiparasitic",
    "Anesthesia/Sedation",
    "NSAID/Pain",
    "Cardiac",
    "Endocrine",
    "Fluid/Electrolyte",
    "Dermatology",
    "Gastroenterology",
    "Neurology",
    "Oncology",
    "Respiratory",
    "Ophthalmology",
    "Renal/Urology",
    "Emergency",
    "Vaccine"
)
