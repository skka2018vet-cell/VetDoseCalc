package com.vetdose.calc.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.vetdose.calc.model.Drug

class DrugRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("vet_dose_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val CUSTOM_DRUGS_KEY = "custom_drugs"

    private val builtInDrugs: List<Drug> = listOf(

        // ══ ANTIBIOTICS ══
        Drug("amoxicillin","Amoxicillin","Antibiotic",listOf("Dog","Cat"),
            11.0,22.0,"mg/kg","PO",150.0,"mg/ml","q8-12h",
            "Broad-spectrum penicillin. Give with or without food.","Penicillin hypersensitivity."),
        Drug("amox_clav","Amoxicillin-Clavulanate (Synulox)","Antibiotic",listOf("Dog","Cat"),
            12.5,25.0,"mg/kg","PO",62.5,"mg/ml","q12h",
            "Beta-lactamase resistant. Skin, UTI, soft tissue. Give with food.","Penicillin allergy."),
        Drug("cephalexin","Cephalexin","Antibiotic",listOf("Dog","Cat"),
            15.0,30.0,"mg/kg","PO",250.0,"mg/ml","q8-12h",
            "1st-gen cephalosporin. Skin/pyoderma/UTI.","Cross-reaction with penicillin allergy (~5%)."),
        Drug("cefpodoxime","Cefpodoxime (Simplicef)","Antibiotic",listOf("Dog"),
            5.0,10.0,"mg/kg","PO",100.0,"mg/ml","q24h",
            "3rd-gen cephalosporin. Once daily. Skin infections.","Not well-established in cats."),
        Drug("cefovecin","Cefovecin (Convenia)","Antibiotic",listOf("Dog","Cat"),
            8.0,8.0,"mg/kg","SC",80.0,"mg/ml","Single injection (14-day effect)",
            "Long-acting SC single dose. Skin/UTI/wounds.","Cannot reverse if adverse reaction occurs."),
        Drug("clindamycin","Clindamycin (Antirobe)","Antibiotic",listOf("Dog","Cat"),
            5.5,11.0,"mg/kg","PO",25.0,"mg/ml","q12h",
            "Anaerobes, dental, bone, toxoplasmosis.","NEVER use in rabbits/guinea pigs — fatal. GI upset."),
        Drug("doxycycline","Doxycycline","Antibiotic",listOf("Dog","Cat"),
            5.0,10.0,"mg/kg","PO",10.0,"mg/ml","q12h",
            "Rickettsia, Mycoplasma, Bartonella. Always give with food and water.","Esophageal stricture in cats — syringe water after. Avoid in pregnancy."),
        Drug("enrofloxacin_dog","Enrofloxacin Dog (Baytril)","Antibiotic",listOf("Dog"),
            5.0,20.0,"mg/kg","PO/IV",50.0,"mg/ml","q24h",
            "Fluoroquinolone. UTI, respiratory, skin.","Avoid in growing dogs. Max 20 mg/kg/day.",20.0),
        Drug("enrofloxacin_cat","Enrofloxacin Cat (Baytril)","Antibiotic",listOf("Cat"),
            2.5,2.5,"mg/kg","PO",22.7,"mg/ml","q24h",
            "STRICT: 2.5 mg/kg/day ONLY in cats.","⚠️ BLINDNESS at >5 mg/kg. Never exceed 2.5 mg/kg.",2.5),
        Drug("marbofloxacin","Marbofloxacin (Marbocyl)","Antibiotic",listOf("Dog","Cat"),
            2.0,5.5,"mg/kg","PO",20.0,"mg/ml","q24h",
            "Fluoroquinolone. UTI, skin, respiratory. Cat: 2 mg/kg q24h.","Avoid in growing animals."),
        Drug("metronidazole","Metronidazole (Flagyl)","Antibiotic",listOf("Dog","Cat"),
            7.5,15.0,"mg/kg","PO",50.0,"mg/ml","q12h",
            "Anaerobes, Giardia, IBD. Cat: 7.5-10 mg/kg q12h.","Neurological toxicity at high/prolonged doses. Bitter taste."),
        Drug("trimeth_sulfa","Trimethoprim-Sulpha (TMS)","Antibiotic",listOf("Dog","Cat"),
            15.0,30.0,"mg/kg","PO",48.0,"mg/ml","q12h",
            "Broad-spectrum. UTI, respiratory. Toxoplasma (with pyrimethamine).","KCS in dogs. Bone marrow suppression. Avoid in Dobermans."),
        Drug("azithromycin","Azithromycin (Zithromax)","Antibiotic",listOf("Dog","Cat"),
            5.0,10.0,"mg/kg","PO",40.0,"mg/ml","q24h x5 days or q72h",
            "Macrolide. Respiratory, Bartonella, Mycoplasma. Good tissue penetration.","GI upset. Drug interactions. Cardiac arrhythmia risk."),
        Drug("chloramphenicol","Chloramphenicol","Antibiotic",listOf("Dog","Cat"),
            40.0,50.0,"mg/kg","PO/IV/IM",250.0,"mg/ml","q8h (dog) / q12h (cat)",
            "Broad-spectrum. CNS penetration. Cat: 12.5-20 mg/kg q12h.","Bone marrow suppression. Gloves when handling. Aplastic anaemia risk (humans)."),
        Drug("nitrofurantoin","Nitrofurantoin","Antibiotic",listOf("Dog","Cat"),
            4.0,5.0,"mg/kg","PO",25.0,"mg/ml","q8h",
            "UTI only — therapeutic only in urine. Chronic/recurrent UTI.","Not for systemic infections. GI upset."),

        // ══ ANTIPARASITICS ══
        Drug("fenbendazole","Fenbendazole (Panacur)","Antiparasitic",listOf("Dog","Cat"),
            25.0,50.0,"mg/kg","PO",100.0,"mg/ml","q24h x3-5 days",
            "Roundworms, hookworms, whipworms, Giardia (50 mg/kg x5d). Very safe.","Vomiting rare. Giardia requires full 5 days."),
        Drug("pyrantel","Pyrantel Pamoate","Antiparasitic",listOf("Dog","Cat"),
            5.0,10.0,"mg/kg","PO",50.0,"mg/ml","Once, repeat in 2-3 weeks",
            "Roundworms and hookworms. OTC. Safe in puppies/kittens 2 weeks+.","Does not cover whipworms or tapeworms."),
        Drug("praziquantel","Praziquantel (Droncit)","Antiparasitic",listOf("Dog","Cat"),
            5.0,10.0,"mg/kg","PO/SC",56.8,"mg/ml","Once",
            "Tapeworms. Dog/Cat: 5 mg/kg PO. SC option available.","SC injection can be painful."),
        Drug("milbemycin","Milbemycin Oxime (Interceptor)","Antiparasitic",listOf("Dog","Cat"),
            0.5,1.0,"mg/kg","PO",2.3,"mg/ml","Monthly",
            "Heartworm prevention, GI worms. Cat: 2 mg/kg monthly.","Caution MDR1 dogs at high doses."),
        Drug("selamectin","Selamectin (Revolution)","Antiparasitic",listOf("Dog","Cat"),
            6.0,12.0,"mg/kg","Topical",60.0,"mg/ml","Monthly",
            "Fleas, heartworm, ear mites, sarcoptic mange, roundworms.","Topical — avoid eyes."),
        Drug("fluralaner","Fluralaner (Bravecto)","Antiparasitic",listOf("Dog","Cat"),
            25.0,56.0,"mg/kg","PO/Topical",280.0,"mg/ml","q12 weeks",
            "Fleas and ticks. Dog oral 25-56 mg/kg. Cat topical. 12-week duration.","Seizure risk in epileptic dogs. Avoid <6 months/<2 kg."),
        Drug("afoxolaner","Afoxolaner (NexGard)","Antiparasitic",listOf("Dog"),
            2.5,2.5,"mg/kg","PO",28.3,"mg/ml","Monthly",
            "Fleas and ticks. Oral chew. Rapid onset.","Dog only. Seizure risk in epileptic dogs."),
        Drug("ivermectin_hwd","Ivermectin Heartworm Prevention","Antiparasitic",listOf("Dog"),
            0.006,0.012,"mg/kg","PO",0.272,"mg/ml","Monthly",
            "Prevention dose ONLY. Commercial product recommended.","⚠️ FATAL in collies, shelties, Aussies (MDR1 mutation). Never use these breeds."),
        Drug("spinosad","Spinosad (Comfortis)","Antiparasitic",listOf("Dog","Cat"),
            30.0,60.0,"mg/kg","PO",270.0,"mg/ml","Monthly",
            "Oral flea adulticidal. Rapid kill. Give with food.","Do not combine with high-dose ivermectin. Vomiting without food."),
        Drug("imidacloprid_mox","Imidacloprid+Moxidectin (Advocate)","Antiparasitic",listOf("Dog","Cat"),
            10.0,10.0,"mg/kg","Topical",100.0,"mg/ml","Monthly",
            "Fleas, heartworm, mange, ear mites, GI parasites. Spot-on.","Avoid water 2 days post-application."),

        // ══ ANESTHESIA / SEDATION ══
        Drug("ketamine","Ketamine","Anesthesia/Sedation",listOf("Dog","Cat"),
            5.0,22.0,"mg/kg","IM/IV",100.0,"mg/ml","Per procedure",
            "Dissociative. Cat IM: 11-22 mg/kg. Dog IV: 5-10 mg/kg. Combine with midazolam or dexmedetomidine.","Increases ICP/IOP. Maintain airway. Avoid in seizure history."),
        Drug("propofol","Propofol","Anesthesia/Sedation",listOf("Dog","Cat"),
            4.0,8.0,"mg/kg","IV slow",10.0,"mg/ml","Per procedure",
            "IV induction. Titrate over 60s. Dog: 4-6 mg/kg. Cat: 4-8 mg/kg.","Apnea — have intubation ready. Heinz body anaemia cats with repeated use."),
        Drug("alfaxalone","Alfaxalone (Alfaxan)","Anesthesia/Sedation",listOf("Dog","Cat"),
            1.0,3.0,"mg/kg","IV/IM",10.0,"mg/ml","Per procedure",
            "Neurosteroid. Dog IV: 1-2 mg/kg. Cat IV: 1-3 mg/kg. IM: 2-3 mg/kg. Safer repeat dosing in cats.","Apnea if given too fast."),
        Drug("dexmedetomidine","Dexmedetomidine (Dexdomitor)","Anesthesia/Sedation",listOf("Dog","Cat"),
            5.0,20.0,"ug/kg","IM/IV",0.5,"mg/ml","Per procedure",
            "Alpha-2 agonist. Dog: 5-20 mcg/kg IM. Cat: 10-40 mcg/kg IM. Potent analgesia.","Bradycardia, hypotension. Have atipamezole ready. Cardiac disease caution."),
        Drug("medetomidine","Medetomidine (Domitor)","Anesthesia/Sedation",listOf("Dog","Cat"),
            10.0,80.0,"ug/kg","IM/IV",1.0,"mg/ml","Per procedure",
            "Alpha-2 agonist. Dog: 10-40 mcg/kg. Cat: 50-80 mcg/kg.","Cardiovascular depression. Reverse with atipamezole."),
        Drug("atipamezole","Atipamezole (Antisedan)","Anesthesia/Sedation",listOf("Dog","Cat"),
            50.0,200.0,"ug/kg","IM",5.0,"mg/ml","Reversal",
            "Alpha-2 reversal. Equal volume rule to medetomidine used.","IM ONLY — IV causes acute hypotension. Monitor 30-60 min post."),
        Drug("midazolam","Midazolam","Anesthesia/Sedation",listOf("Dog","Cat"),
            0.2,0.5,"mg/kg","IM/IV",5.0,"mg/ml","Per procedure",
            "Benzodiazepine. Co-induction, sedation, muscle relaxation, seizure control.","Paradoxical excitement possible. Reverse with flumazenil."),
        Drug("diazepam","Diazepam (Valium)","Anesthesia/Sedation",listOf("Dog","Cat"),
            0.25,0.5,"mg/kg","IV/Rectal",5.0,"mg/ml","Per procedure / q8-12h",
            "Seizure control, co-induction. Rectal for home seizure management.","IV only (no IM). Adsorbs to plastic — give promptly. Oral hepatotoxicity in cats."),
        Drug("butorphanol","Butorphanol (Torbugesic)","Anesthesia/Sedation",listOf("Dog","Cat"),
            0.2,0.4,"mg/kg","IM/IV/SC",10.0,"mg/ml","q4-6h",
            "Kappa-opioid. Pre-med, mild analgesia, antitussive. Cats: good sedation component.","Ceiling effect for analgesia."),
        Drug("buprenorphine","Buprenorphine","Anesthesia/Sedation",listOf("Dog","Cat"),
            0.01,0.03,"mg/kg","IM/IV/Buccal",0.3,"mg/ml","q6-8h",
            "Partial mu-agonist. Moderate analgesia. Cat: buccal route highly effective.","Slow onset 30-45 min. Partial agonist ceiling effect."),
        Drug("morphine","Morphine Sulphate","Anesthesia/Sedation",listOf("Dog","Cat"),
            0.1,0.5,"mg/kg","IM/SC/IV slow",10.0,"mg/ml","q4-6h",
            "Full mu-agonist. Strong analgesia. Cat: 0.1-0.2 mg/kg (lower dose).","Histamine with rapid IV. Respiratory depression. Dysphoria in cats."),
        Drug("acepromazine","Acepromazine (ACP)","Anesthesia/Sedation",listOf("Dog","Cat"),
            0.025,0.05,"mg/kg","IM/SC/IV",2.0,"mg/ml","Pre-med (once)",
            "Phenothiazine tranquiliser. Pre-med. Dog max 3 mg total. Cat max 1 mg total.","No analgesia. Hypotension. No reversal. Avoid epileptics/shock/cardiac.", 3.0),
        Drug("telazol","Tiletamine-Zolazepam (Telazol/Zoletil)","Anesthesia/Sedation",listOf("Dog","Cat"),
            4.0,6.0,"mg/kg","IM",100.0,"mg/ml","Per procedure",
            "Dissociative + BDZ combination. IM when IV not accessible. Reconstitute per label.","No specific reversal. Prolonged recovery in cats."),

        // ══ NSAIDs / PAIN ══
        Drug("meloxicam_dog","Meloxicam Dog (Metacam)","NSAID/Pain",listOf("Dog"),
            0.2,0.2,"mg/kg","PO/SC",1.5,"mg/ml","Loading day 1; then 0.1 mg/kg q24h",
            "Loading: 0.2 mg/kg. Maintenance: 0.1 mg/kg/day. Post-op SC: 0.2 mg/kg once.","GI ulceration, renal toxicity. Never combine with steroids/other NSAIDs."),
        Drug("meloxicam_cat","Meloxicam Cat (Metacam)","NSAID/Pain",listOf("Cat"),
            0.05,0.1,"mg/kg","SC/PO",0.5,"mg/ml","Acute: once; Chronic: 0.025 mg/kg q48h with monitoring",
            "Post-op acute SC: 0.1 mg/kg once. Chronic: VERY conservative — 0.025 mg/kg q48h.","⚠️ CATS EXTREMELY SENSITIVE. Acute renal failure risk. Monitor renal function frequently."),
        Drug("carprofen","Carprofen (Rimadyl)","NSAID/Pain",listOf("Dog"),
            2.2,4.4,"mg/kg","PO/SC",50.0,"mg/ml","q12-24h",
            "Arthritis, post-op. 4.4 mg/kg/day total. Give with food.","Hepatotoxicity (Labradors). GI ulceration, renal toxicity."),
        Drug("robenacoxib","Robenacoxib (Onsior)","NSAID/Pain",listOf("Dog","Cat"),
            1.0,2.0,"mg/kg","PO/SC",20.0,"mg/ml","q24h (max 3d SC; 6d PO dog)",
            "COX-2 selective. Cat: 1 mg/kg PO q24h (up to 6 days). Dog post-op SC: 2 mg/kg.","Short-term use only."),
        Drug("gabapentin","Gabapentin","NSAID/Pain",listOf("Dog","Cat"),
            5.0,10.0,"mg/kg","PO",50.0,"mg/ml","q8-12h",
            "Neuropathic pain, anxiety, seizure adjunct. Dog: 10 mg/kg q8-12h. Cat: 5-10 mg/kg q8-12h.","Sedation, ataxia. Reduce in renal disease. Check liquid formulations for xylitol!"),
        Drug("pregabalin","Pregabalin (Lyrica)","NSAID/Pain",listOf("Dog","Cat"),
            2.0,4.0,"mg/kg","PO",20.0,"mg/ml","q8-12h",
            "Neuropathic pain, epilepsy adjunct. More potent than gabapentin.","Sedation, ataxia."),
        Drug("tramadol","Tramadol","NSAID/Pain",listOf("Dog","Cat"),
            2.0,5.0,"mg/kg","PO",50.0,"mg/ml","q8-12h (dog); q12h (cat)",
            "Adjunct chronic pain. Cat: 1-4 mg/kg q12h.","Limited efficacy in dogs as sole agent. Serotonin syndrome with MAOIs/SSRIs."),
        Drug("paracetamol_dog","Paracetamol (Dog ONLY)","NSAID/Pain",listOf("Dog"),
            10.0,15.0,"mg/kg","PO",120.0,"mg/ml","q8-12h (short term only)",
            "Adjunct analgesia in dogs ONLY. Use with caution, short-term.","⚠️ FATAL IN CATS — even tiny doses cause methemoglobinaemia and liver failure. NEVER give to cats."),
        Drug("amantadine","Amantadine","NSAID/Pain",listOf("Dog","Cat"),
            3.0,5.0,"mg/kg","PO",10.0,"mg/ml","q24h",
            "NMDA antagonist. Chronic pain adjunct (OA, cancer pain). Often combined with NSAID/gabapentin.","Agitation, GI upset. Reduce in renal disease."),
        Drug("buprenorphine_pain","Buprenorphine (Pain)","NSAID/Pain",listOf("Dog","Cat"),
            0.01,0.02,"mg/kg","IM/IV/Buccal",0.3,"mg/ml","q6-8h",
            "Moderate post-op analgesia. Cat buccal route excellent. Dog: IV/IM preferred.","Slow onset. Ceiling effect."),

        // ══ CARDIAC ══
        Drug("pimobendan","Pimobendan (Vetmedin)","Cardiac",listOf("Dog"),
            0.2,0.3,"mg/kg","PO",1.25,"mg/ml","q12h — 1 hour BEFORE food",
            "Inodilator. MVD, DCM. Give on empty stomach. Start before CHF signs in pre-clinical MVD.","Do NOT use in outflow obstruction. Dog only."),
        Drug("atenolol","Atenolol","Cardiac",listOf("Dog","Cat"),
            0.25,1.0,"mg/kg","PO",5.0,"mg/ml","q12-24h",
            "Beta-1 blocker. Feline HCM rate control, arrhythmias.","Bradycardia, hypotension. Do not stop abruptly. Avoid in asthmatic cats."),
        Drug("sotalol","Sotalol","Cardiac",listOf("Dog","Cat"),
            1.0,2.0,"mg/kg","PO",5.0,"mg/ml","q12h",
            "Class III antiarrhythmic. Ventricular arrhythmias (Boxers, Dobermans).","Pro-arrhythmic. ECG monitoring required."),
        Drug("diltiazem","Diltiazem (Cardizem)","Cardiac",listOf("Dog","Cat"),
            0.5,2.5,"mg/kg","PO",12.0,"mg/ml","q8h (standard) / q12h (SR)",
            "Ca-channel blocker. Feline HCM, SVT rate control. Cat: 1.75-2.5 mg/kg q8h.","Bradycardia, hypotension. Negative inotrope."),
        Drug("furosemide","Furosemide (Lasix)","Cardiac",listOf("Dog","Cat"),
            1.0,4.0,"mg/kg","PO/IM/IV",50.0,"mg/ml","q8-12h",
            "Loop diuretic. Pulmonary oedema, CHF. Acute crisis: 2-4 mg/kg IV.","Hypokalemia, dehydration, azotemia. Monitor electrolytes/renal function."),
        Drug("torasemide","Torasemide (Isemid)","Cardiac",listOf("Dog"),
            0.1,0.3,"mg/kg","PO",4.0,"mg/ml","q24h",
            "Potent loop diuretic (10x furosemide). Once daily. Resistant CHF.","Electrolyte disturbances."),
        Drug("spironolactone","Spironolactone (Aldactone)","Cardiac",listOf("Dog","Cat"),
            1.0,2.0,"mg/kg","PO",5.0,"mg/ml","q12-24h",
            "K-sparing diuretic. CHF adjunct, cardioprotective in MVD.","Hyperkalemia. Facial ulceration in cats (rare)."),
        Drug("benazepril","Benazepril (Fortekor)","Cardiac",listOf("Dog","Cat"),
            0.25,0.5,"mg/kg","PO",2.5,"mg/ml","q24h",
            "ACE inhibitor. CHF, proteinuric nephropathy (cats), MVD. Vasodilation.","Hypotension, azotemia. Monitor renal function. Avoid with NSAIDs."),
        Drug("enalapril","Enalapril (Enacard)","Cardiac",listOf("Dog","Cat"),
            0.25,0.5,"mg/kg","PO",2.5,"mg/ml","q12-24h",
            "ACE inhibitor. CHF, hypertension, cardiomyopathy.","Hypotension, azotemia. Monitor renal function."),
        Drug("digoxin","Digoxin","Cardiac",listOf("Dog","Cat"),
            0.005,0.01,"mg/kg","PO",0.05,"mg/ml","q12h — NARROW THERAPEUTIC INDEX",
            "Positive inotrope, vagotonic. AF rate control, DCM.","⚠️ NARROW INDEX. Toxic: vomiting, arrhythmia. Monitor serum levels. Many drug interactions."),
        Drug("amlodipine","Amlodipine (Norvasc)","Cardiac",listOf("Dog","Cat"),
            0.1,0.5,"mg/kg","PO",1.0,"mg/ml","q24h",
            "Ca-channel blocker. Systemic hypertension. Feline: 0.625-1.25 mg/cat q24h (first-line).","Hypotension, gingival hyperplasia (dog)."),

        // ══ ENDOCRINE ══
        Drug("methimazole","Methimazole (Felimazole)","Endocrine",listOf("Cat"),
            2.5,5.0,"mg/kg","PO/Transdermal",2.5,"mg/ml","q12h (start low, titrate)",
            "Feline hyperthyroidism. Start 2.5 mg/cat q12h. Check T4 q3-4 weeks.","Facial pruritus, hepatotoxicity, thrombocytopenia. Monitor CBC/biochemistry."),
        Drug("carbimazole","Carbimazole","Endocrine",listOf("Cat"),
            5.0,5.0,"mg/kg","PO",5.0,"mg/ml","q8h initially, q12h maintenance",
            "Prodrug of methimazole. Feline hyperthyroidism.","Same as methimazole. Monitor regularly."),
        Drug("levothyroxine","Levothyroxine (Soloxine)","Endocrine",listOf("Dog"),
            0.02,0.02,"mg/kg","PO",0.2,"mg/ml","q12h (ideal) or q24h",
            "Hypothyroidism. Starting dose 20 mcg/kg q12h. Check T4 at 4-6 weeks post-pill 4-6h.","Tachycardia if overdosed. Many drug interactions."),
        Drug("prednisolone","Prednisolone","Endocrine",listOf("Dog","Cat"),
            1.0,2.0,"mg/kg","PO",5.0,"mg/ml","q12-24h anti-inflam; taper to q48h",
            "Anti-inflammatory: 1-2 mg/kg/day. Immunosuppressive: 2-4 mg/kg/day. Taper for long-term.","PU/PD, GI ulceration, infections, muscle wasting. Avoid live vaccines."),
        Drug("dexamethasone","Dexamethasone","Endocrine",listOf("Dog","Cat"),
            0.1,0.2,"mg/kg","IV/IM/SC",2.0,"mg/ml","q12-24h (short term)",
            "Potent glucocorticoid (7-10x pred). Shock, cerebral oedema, anaphylaxis, hypercalcaemia.","Adrenal suppression. Do not use in late pregnancy."),
        Drug("insulin_nph","NPH/Lente Insulin (Caninsulin)","Endocrine",listOf("Dog","Cat"),
            0.25,0.5,"IU/kg","SC",40.0,"IU/ml","q12h — titrate by glucose curves",
            "DM. Dog start 0.25-0.5 IU/kg q12h. Cat: 1-2 IU/cat q12h. Glucose curves essential.","Hypoglycaemia. Always start low and titrate. Glucose curve before dose changes."),
        Drug("insulin_glargine","Insulin Glargine (Lantus)","Endocrine",listOf("Cat"),
            0.25,0.5,"IU/kg","SC",100.0,"IU/ml","q12h — titrate",
            "Preferred for diabetic cats. Low-carb diet + glargine = best remission rates.","Hypoglycaemia. Start 0.25-0.5 IU/kg (max 2 IU/cat) q12h."),
        Drug("trilostane","Trilostane (Vetoryl)","Endocrine",listOf("Dog"),
            1.0,5.0,"mg/kg","PO",60.0,"mg/ml","q24h (some q12h)",
            "Cushing's syndrome (PDH/ADH). Start 1-2 mg/kg q24h with food. ACTH stim test at 10 days.","Adrenal necrosis, Addisonian crisis. ACTH stimulation monitoring ESSENTIAL."),
        Drug("mitotane","Mitotane (Lysodren)","Endocrine",listOf("Dog"),
            25.0,50.0,"mg/kg","PO",500.0,"mg/ml","Induction daily; maintenance weekly",
            "Cushing's. Induction 25-50 mg/kg/day with food until response. Alternative to trilostane.","Addisonian crisis risk. Strict monitoring. Keep prednisolone on hand."),

        // ══ FLUIDS / ELECTROLYTES ══
        Drug("lrs","Lactated Ringer's Solution (LRS)","Fluid/Electrolyte",listOf("Dog","Cat"),
            10.0,20.0,"ml/kg","IV",1000.0,"ml","Shock bolus; maintenance 2-3 ml/kg/h",
            "Isotonic crystalloid. Shock: 10-20 ml/kg bolus over 15-30 min.","Volume overload in cardiac/renal disease."),
        Drug("saline_09","0.9% NaCl (Normal Saline)","Fluid/Electrolyte",listOf("Dog","Cat"),
            10.0,20.0,"ml/kg","IV",1000.0,"ml","Shock bolus; adjust to response",
            "Isotonic crystalloid. Preferred for vomiting/hypochloraemic patients.","Hyperchloraemic acidosis with large volumes."),
        Drug("kcl","Potassium Chloride (KCl)","Fluid/Electrolyte",listOf("Dog","Cat"),
            0.5,1.0,"mEq/kg/hr","IV CRI in fluids",2.0,"mEq/ml","Add to IV fluid bag — CRI only",
            "Supplement for hypokalaemia. Max 0.5 mEq/kg/h. Add to fluid bag.","⚠️ NEVER BOLUS — fatal cardiac arrest."),
        Drug("hetastarch","Hetastarch 6% (Colloid)","Fluid/Electrolyte",listOf("Dog","Cat"),
            5.0,10.0,"ml/kg","IV slow bolus",60.0,"mg/ml","Bolus, repeat as needed",
            "Colloid. Hypoalbuminaemia, shock. Dog: max 20 ml/kg/day. Cat: use with care max 10-15 ml/kg/day.","Coagulopathy, AKI with large doses. Use minimum effective volume."),

        // ══ DERMATOLOGY ══
        Drug("oclacitinib","Oclacitinib (Apoquel)","Dermatology",listOf("Dog"),
            0.4,0.6,"mg/kg","PO",3.6,"mg/ml","q12h x14d then q24h",
            "JAK inhibitor. Pruritus/atopic dermatitis. Dog >12 months. Rapid onset (hours).","Immunosuppression. Seizure risk in epileptic dogs. Monitor for neoplasia long-term."),
        Drug("lokivetmab","Lokivetmab (Cytopoint)","Dermatology",listOf("Dog"),
            1.0,2.0,"mg/kg","SC",10.0,"mg/ml","q4-8 weeks",
            "Anti-IL-31 monoclonal antibody. Canine atopic dermatitis. 4-8 week duration per injection.","Very safe. Injection site reaction."),
        Drug("ciclosporin","Ciclosporin (Atopica)","Dermatology",listOf("Dog","Cat"),
            5.0,7.0,"mg/kg","PO",100.0,"mg/ml","q24h then taper",
            "Calcineurin inhibitor. Atopy, pemphigus, feline IBD. Cat: 5-7.5 mg/kg q24h.","GI upset, gingival hyperplasia, papillomatosis. Lymphoma risk long-term. Toxoplasma reactivation."),

        // ══ GASTROENTEROLOGY ══
        Drug("omeprazole","Omeprazole","Gastroenterology",listOf("Dog","Cat"),
            0.5,1.0,"mg/kg","PO",2.0,"mg/ml","q24h (dog); q24-48h (cat)",
            "PPI. Gastric ulcers, NSAID protection, mast cell tumour. Give 30-60 min before food.","Rebound acid with abrupt stopping. Drug absorption interactions."),
        Drug("pantoprazole","Pantoprazole (IV)","Gastroenterology",listOf("Dog","Cat"),
            0.5,1.0,"mg/kg","IV slow",4.0,"mg/ml","q24h",
            "IV PPI for hospitalised patients. Infuse over 15 min.","Switch to oral when able."),
        Drug("maropitant","Maropitant (Cerenia)","Gastroenterology",listOf("Dog","Cat"),
            1.0,2.0,"mg/kg","SC/IV/PO",10.0,"mg/ml","q24h",
            "NK1 antiemetic. Vomiting, nausea, motion sickness. SC stings — refrigerate then warm.","Do not use <16 weeks (dog) or <8 weeks (cat)."),
        Drug("metoclopramide","Metoclopramide","Gastroenterology",listOf("Dog","Cat"),
            0.2,0.5,"mg/kg","PO/SC/IV/CRI",5.0,"mg/ml","q6-8h or CRI 1-2 mg/kg/day",
            "Prokinetic + antiemetic. Gastric stasis, oesophageal reflux. CRI preferred for hospitalised.","Extrapyramidal signs at high doses. Avoid GI obstruction."),
        Drug("ondansetron","Ondansetron (Zofran)","Gastroenterology",listOf("Dog","Cat"),
            0.1,0.5,"mg/kg","PO/IV",2.0,"mg/ml","q8-12h",
            "5-HT3 antiemetic. Chemotherapy nausea, parvo, pancreatitis.","Constipation. Expensive."),
        Drug("sucralfate","Sucralfate (Antepsin)","Gastroenterology",listOf("Dog","Cat"),
            0.25,1.0,"g/kg","PO",1.0,"g/tablet","q6-8h — give separately from other meds",
            "Mucosal protectant. GI ulcers, oesophagitis. Dog: 0.5-1 g q8h. Cat: 0.25-0.5 g q12h.","Constipation. Binds other drugs — give 2h apart."),
        Drug("famotidine","Famotidine (Pepcid)","Gastroenterology",listOf("Dog","Cat"),
            0.5,1.0,"mg/kg","PO/IV",10.0,"mg/ml","q12-24h",
            "H2 blocker. Gastric acid reduction. Useful when IV route needed.","Less effective than PPI for severe disease."),

        // ══ NEUROLOGY / SEIZURES ══
        Drug("phenobarbital","Phenobarbital (Epiphen)","Neurology",listOf("Dog","Cat"),
            2.0,3.0,"mg/kg","PO/IV",65.0,"mg/ml","q12h",
            "First-line epilepsy. Start 2-3 mg/kg q12h. Status: 12-20 mg/kg IV slowly.","Sedation, hepatotoxicity, polyphagia, PU/PD. Monitor liver. Controlled drug."),
        Drug("potassium_bromide","Potassium Bromide","Neurology",listOf("Dog"),
            20.0,30.0,"mg/kg","PO",250.0,"mg/ml","q24h",
            "Adjunct/alternative epilepsy dog. Load 400-600 mg/kg over 5 days for rapid control.","⚠️ NEVER USE IN CATS — fatal respiratory disease. Sedation."),
        Drug("levetiracetam","Levetiracetam (Keppra)","Neurology",listOf("Dog","Cat"),
            20.0,60.0,"mg/kg","PO/IV",100.0,"mg/ml","q8h",
            "Adjunct epilepsy, cluster seizures. IV status: 30-60 mg/kg slowly. Safe in liver disease.","Sedation, ataxia. Very safe profile."),
        Drug("zonisamide","Zonisamide (Zonegran)","Neurology",listOf("Dog","Cat"),
            5.0,10.0,"mg/kg","PO",100.0,"mg/ml","q12-24h",
            "Adjunct epilepsy. Dog: q12h. Cat: q24h.","Renal tubular acidosis, urolithiasis (rare). Sulphonamide-based."),
        Drug("diazepam_sz","Diazepam (Seizure)","Neurology",listOf("Dog","Cat"),
            0.5,1.0,"mg/kg","IV/Rectal",5.0,"mg/ml","Repeat q5-10 min (max 3 doses)",
            "First-line acute seizure. IV: 0.5 mg/kg. Rectal: 1-2 mg/kg. Repeat after 5-10 min.","Respiratory depression. Use glass syringe (adsorbs to plastic). Oral hepatotoxicity cats."),
        Drug("midazolam_sz","Midazolam (Seizure)","Neurology",listOf("Dog","Cat"),
            0.2,0.5,"mg/kg","IV/IM/IN",5.0,"mg/ml","Repeat q5-10 min",
            "Preferred for IM/IN route. Intranasal: 0.2-0.3 mg/kg. Faster IM absorption than diazepam.","Respiratory depression with concurrent opioids."),

        // ══ EMERGENCY / TOXICOLOGY ══
        Drug("atropine_brady","Atropine (Bradycardia/CPR)","Emergency",listOf("Dog","Cat"),
            0.02,0.04,"mg/kg","IV/IM/IT",0.6,"mg/ml","Repeat q3-5 min PRN",
            "Anticholinergic. Sinus bradycardia, AV block, CPR. IT: double IV dose.","Tachycardia, ileus, urinary retention, dry mouth."),
        Drug("epinephrine","Epinephrine (CPR)","Emergency",listOf("Dog","Cat"),
            0.01,0.01,"mg/kg","IV/IO/IT",1.0,"mg/ml","q3-5 min during CPR",
            "CPR RECOVER protocol. Low dose IV: 0.01 mg/kg. IT: 0.1 mg/kg. IO same as IV.","VF post-ROSC. Use low dose."),
        Drug("naloxone","Naloxone (Narcan)","Emergency",listOf("Dog","Cat"),
            0.01,0.04,"mg/kg","IV/IM/SC/IT",0.4,"mg/ml","Repeat q20-40 min PRN",
            "Opioid reversal. Full: 0.04 mg/kg IV. Partial: 0.01-0.02 mg/kg to preserve some analgesia.","Resedation after 20-40 min. Acute pain on reversal."),
        Drug("apomorphine","Apomorphine (emesis — dog)","Emergency",listOf("Dog"),
            0.03,0.04,"mg/kg","IV/Conjunctival",10.0,"mg/ml","Once",
            "Dog emesis induction. IV: 0.03-0.04 mg/kg. Conjunctival: crush tablet, apply, remove after vomiting.","DO NOT USE IN CATS. Protracted vomiting, respiratory depression. Reverse with naloxone."),
        Drug("dexmed_emesis","Dexmedetomidine (emesis — cat)","Emergency",listOf("Cat"),
            7.0,7.0,"ug/kg","IM",0.5,"mg/ml","Once",
            "Preferred feline emetic (7 mcg/kg IM = ~100% emesis). Reverse with atipamezole after.","Sedation — reverse when done. Monitor cardiovascular system."),
        Drug("vitamin_k1","Vitamin K1 (Phytomenadione)","Emergency",listOf("Dog","Cat"),
            2.5,5.0,"mg/kg","SC/PO",10.0,"mg/ml","q12h x 1-4 weeks (depends on toxin)",
            "Anticoagulant rodenticide toxicity. SC first dose then switch to PO. Duration depends on rodenticide.","SC can cause anaphylaxis — give slowly. IV contraindicated. Never IM (haematoma)."),
        Drug("acetylcysteine","N-Acetylcysteine (NAC)","Emergency",listOf("Dog","Cat"),
            140.0,140.0,"mg/kg","IV/PO",200.0,"mg/ml","Loading 140 mg/kg; then 70 mg/kg q6h x7 doses",
            "Paracetamol toxicity (ESPECIALLY CATS), hepatic support.","Dilute to 5% for IV. Anaphylactoid reaction (rare IV)."),
        Drug("intralipid","Intralipid 20% (Lipid Emulsion)","Emergency",listOf("Dog","Cat"),
            1.5,1.5,"ml/kg","IV bolus",200.0,"mg/ml","1.5 ml/kg bolus then 0.25 ml/kg/min CRI x30-60 min",
            "Lipophilic toxin sequestration (LA, ivermectin, permethrin, baclofen).","Pancreatitis, thromboembolism. Use when standard therapy insufficient."),

        // ══ RESPIRATORY ══
        Drug("theophylline","Theophylline SR","Respiratory",listOf("Dog","Cat"),
            10.0,20.0,"mg/kg","PO",100.0,"mg/ml","q12h (dog SR); q24h at night (cat SR)",
            "Bronchodilator. Chronic bronchitis, feline asthma. Cat: 25 mg/kg SR q24h at night.","Narrow therapeutic index. Tachycardia, seizures, GI toxicity. Monitor levels."),
        Drug("terbutaline","Terbutaline","Respiratory",listOf("Dog","Cat"),
            0.01,0.01,"mg/kg","SC/IM",1.0,"mg/ml","q4h PRN",
            "Beta-2 bronchodilator. Acute feline bronchospasm/asthma crisis. Rescue therapy.","Tachycardia, hypokalaemia. Short duration."),
        Drug("fluticasone","Fluticasone Inhaler (Flixotide)","Respiratory",listOf("Dog","Cat"),
            1.0,1.0,"puff","Inhaled (spacer)",50.0,"ug/puff","q12h",
            "Inhaled corticosteroid. Feline chronic asthma long-term. Use with AeroKat spacer.","Systemic effects less than oral steroids. Local candidiasis (rare)."),

        // ══ ONCOLOGY (supportive) ══
        Drug("prednisolone_onco","Prednisolone (Oncology)","Oncology",listOf("Dog","Cat"),
            1.0,2.0,"mg/kg","PO",5.0,"mg/ml","q24h",
            "Lymphoma palliative/COP protocol. Dog: 2 mg/kg/day. Cat: 1-2 mg/kg/day.","PU/PD, infection risk. Using before chemo can cause resistance."),
        Drug("chlorambucil","Chlorambucil (Leukeran)","Oncology",listOf("Dog","Cat"),
            2.0,6.0,"mg/kg","PO",2.0,"mg/tablet","Pulse q14d or continuous q48h",
            "Alkylating agent. Feline low-grade lymphoma, CLL. Pulse: 15-20 mg/m² q14 days. Feline chronic: 2-4 mg/cat q48h.","Bone marrow suppression. GI signs. Cytotoxic — wear gloves. CBC monitoring."),
        Drug("toceranib","Toceranib (Palladia)","Oncology",listOf("Dog"),
            2.5,2.75,"mg/kg","PO",10.0,"mg/ml","Mon/Wed/Fri (alternate days)",
            "Tyrosine kinase inhibitor. Mast cell tumours. Give with food.","GI toxicity, lameness, hypertension, neutropenia. Regular monitoring essential."),

        // ══ OPHTHALMOLOGY ══
        Drug("latanoprost","Latanoprost 0.005% (Xalatan)","Ophthalmology",listOf("Dog","Cat"),
            1.0,1.0,"drop","Topical (eye)",0.05,"mg/ml","q12-24h",
            "Prostaglandin analogue. Glaucoma. Rapid IOP reduction.","Miosis, conjunctival hyperaemia. Contraindicated in uveitic/secondary glaucoma."),
        Drug("timolol_eye","Timolol 0.5% Eye Drops","Ophthalmology",listOf("Dog","Cat"),
            1.0,1.0,"drop","Topical (eye)",5.0,"mg/ml","q12h",
            "Beta-blocker IOP reduction. Glaucoma adjunct.","Systemic absorption — bradycardia. Avoid in cardiac disease/asthma."),
        Drug("atropine_eye","Atropine 1% Eye Drops","Ophthalmology",listOf("Dog","Cat"),
            1.0,1.0,"drop","Topical (eye)",10.0,"mg/ml","q6-12h",
            "Mydriatic/cycloplegic. Uveitis, corneal ulcer pain relief.","⚠️ Raises IOP — do NOT use in glaucoma. Systemic absorption: tachycardia."),
        Drug("cyclosporin_eye","Cyclosporin 0.2% (Optimmune)","Ophthalmology",listOf("Dog"),
            1.0,1.0,"drop","Topical (eye)",2.0,"mg/ml","q12h",
            "KCS (dry eye) in dogs. Stimulates tear production. Results in 4-6 weeks.","Local irritation. Lifelong treatment usually required."),

        // ══ RENAL / UROLOGY ══
        Drug("prazosin","Prazosin","Renal/Urology",listOf("Dog","Cat"),
            0.025,0.05,"mg/kg","PO",1.0,"mg/ml","q8-12h",
            "Alpha-1 blocker. Urethral spasm, post-obstruction cat. Dog: 0.03-0.05 mg/kg q8h.","Hypotension. First-dose syncope."),
        Drug("bethanechol","Bethanechol","Renal/Urology",listOf("Dog","Cat"),
            2.5,7.5,"mg/kg","PO",5.0,"mg/ml","q8h",
            "Cholinergic. Urinary retention/detrusor atony. Dog: 5-15 mg/dog q8h. Cat: 1.25-5 mg/cat q8h.","GI cramping, vomiting. Contraindicated in obstruction."),

        // ══ VACCINES ══
        Drug("da2pp","DA2PP Vaccine (Core — Dog)","Vaccine",listOf("Dog"),
            1.0,1.0,"dose","SC",1.0,"dose/vial","Puppy series; then q1-3 years",
            "Core: Distemper, Adenovirus-2, Parvovirus, Parainfluenza. Puppy: 8, 12, 16 weeks → 1 year → q3 years.","MLV — avoid in immunosuppressed/pregnant."),
        Drug("fvrcp","FVRCP Vaccine (Core — Cat)","Vaccine",listOf("Cat"),
            1.0,1.0,"dose","SC",1.0,"dose/vial","Kitten series; then q1-3 years",
            "Core: Herpesvirus, Calicivirus, Panleukopenia. Kitten: 8, 12, 16 weeks → 1 year.","Inject designated limb site (sarcoma tracking)."),
        Drug("rabies_dog","Rabies Vaccine — Dog","Vaccine",listOf("Dog"),
            1.0,1.0,"dose","IM",1.0,"dose/vial","Per schedule (1y then q1 or q3 years)",
            "Core. 1 mL IM. Follow local regulations.",""),
        Drug("rabies_cat","Rabies Vaccine — Cat","Vaccine",listOf("Cat"),
            1.0,1.0,"dose","SC (left hindlimb)",1.0,"dose/vial","Per schedule (1y then q1 or q3 years)",
            "Core. Left hindlimb SC for sarcoma site tracking. Killed vaccine preferred for cats.","Vaccine-associated sarcoma risk — injection site tracking important."),
        Drug("bordetella","Bordetella bronchiseptica Vaccine","Vaccine",listOf("Dog","Cat"),
            1.0,1.0,"dose","IN/IM",1.0,"dose/vial","Annual",
            "Non-core. Kennel cough. Intranasal preferred for mucosal immunity.","Mild coughing/discharge post-IN vaccination."),
        Drug("felv","FeLV Vaccine","Vaccine",listOf("Cat"),
            1.0,1.0,"dose","SC (left forelimb)",1.0,"dose/vial","Annual (outdoor/at-risk cats)",
            "Non-core. Test FeLV-negative before vaccinating. 2-dose initial series.","Left forelimb SC (sarcoma tracking). Killed vaccine only.")
    )

    // ─────────────────────────────────────────────────────────────────────────
    //  CUSTOM DRUG STORAGE
    // ─────────────────────────────────────────────────────────────────────────
    fun getCustomDrugs(): List<Drug> {
        val json = prefs.getString(CUSTOM_DRUGS_KEY, "[]") ?: "[]"
        val type = object : TypeToken<List<Drug>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun saveCustomDrug(drug: Drug) {
        val list = getCustomDrugs().toMutableList()
        val idx = list.indexOfFirst { it.id == drug.id }
        if (idx >= 0) list[idx] = drug else list.add(drug)
        prefs.edit().putString(CUSTOM_DRUGS_KEY, gson.toJson(list)).apply()
    }

    fun deleteCustomDrug(id: String) {
        val list = getCustomDrugs().filter { it.id != id }
        prefs.edit().putString(CUSTOM_DRUGS_KEY, gson.toJson(list)).apply()
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  QUERY METHODS
    // ─────────────────────────────────────────────────────────────────────────
    fun getAllDrugs(): List<Drug> = builtInDrugs + getCustomDrugs()

    fun getDrugsBySpecies(species: String): List<Drug> =
        getAllDrugs().filter { it.species.contains(species) }

    fun getDrugsByCategory(category: String): List<Drug> =
        getAllDrugs().filter { it.category == category }

    fun getCategories(): List<String> =
        getAllDrugs().map { it.category }.distinct().sorted()

    fun searchDrugs(query: String): List<Drug> {
        val q = query.trim().lowercase()
        return getAllDrugs().filter {
            it.name.lowercase().contains(q) ||
            it.category.lowercase().contains(q) ||
            it.notes.lowercase().contains(q)
        }
    }

    fun getDrugById(id: String): Drug? = getAllDrugs().firstOrNull { it.id == id }
}
