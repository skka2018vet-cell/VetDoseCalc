package com.vetdose.calc.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.vetdose.calc.data.DoseCalculator
import com.vetdose.calc.data.DoseCalculator.fmt
import com.vetdose.calc.databinding.ItemDrugBinding
import com.vetdose.calc.model.Drug

class DrugListAdapter(
    private var drugs: List<Drug>,
    private var weightKg: Double,
    private val onClick: (Drug) -> Unit
) : RecyclerView.Adapter<DrugListAdapter.DrugVH>() {

    inner class DrugVH(val binding: ItemDrugBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DrugVH {
        val b = ItemDrugBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DrugVH(b)
    }

    override fun getItemCount() = drugs.size

    override fun onBindViewHolder(holder: DrugVH, position: Int) {
        val drug = drugs[position]
        val b = holder.binding

        b.tvDrugName.text = drug.name
        b.tvCategory.text = "${drug.category} • ${drug.species.take(3).joinToString(", ")}"
        b.tvRoute.text = "${drug.route} | ${drug.frequency}"

        if (weightKg > 0) {
            val result = DoseCalculator.calculate(drug, weightKg)
            if (drug.doseMin == drug.doseMax) {
                b.tvDose.text = "${result.doseMinMg.fmt(2)} ${drug.doseUnit.replace("/kg","")}"
            } else {
                b.tvDose.text = "${result.doseMinMg.fmt(2)}–${result.doseMaxMg.fmt(2)} ${drug.doseUnit.replace("/kg","")}"
            }
            if (drug.doseUnit.lowercase().contains("ml") || drug.concentrationUnit.contains("ml")) {
                if (drug.doseMin == drug.doseMax) {
                    b.tvVolume.text = "Vol: ${result.volumeMin.fmt(2)} ml"
                } else {
                    b.tvVolume.text = "Vol: ${result.volumeMin.fmt(2)}–${result.volumeMax.fmt(2)} ml"
                }
            } else {
                if (drug.doseMin == drug.doseMax) {
                    b.tvVolume.text = "Vol: ${result.volumeMin.fmt(2)} ml"
                } else {
                    b.tvVolume.text = "Vol: ${result.volumeMin.fmt(2)}–${result.volumeMax.fmt(2)} ml"
                }
            }
            if (result.isCapped) b.tvVolume.text = "${b.tvVolume.text} ⚠️ max dose capped"
        } else {
            b.tvDose.text = "${drug.doseMin}–${drug.doseMax} ${drug.doseUnit}"
            b.tvVolume.text = "Enter weight above to calculate volume"
        }

        if (drug.isCustom) {
            b.tvCustomBadge.visibility = android.view.View.VISIBLE
        } else {
            b.tvCustomBadge.visibility = android.view.View.GONE
        }

        b.root.setOnClickListener { onClick(drug) }
    }

    fun updateList(newList: List<Drug>) {
        drugs = newList
        notifyDataSetChanged()
    }

    fun setWeight(w: Double) {
        weightKg = w
        notifyDataSetChanged()
    }
}
