package com.vetdose.calc.ui

import android.os.Bundle
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vetdose.calc.data.DrugRepository
import com.vetdose.calc.databinding.ActivityAddEditDrugBinding
import com.vetdose.calc.model.ALL_CATEGORIES
import com.vetdose.calc.model.Drug
import java.util.UUID

class AddEditDrugActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditDrugBinding
    private lateinit var repo: DrugRepository
    private var editDrugId: String? = null

    private val doseUnits    = listOf("mg/kg","ug/kg","IU/kg","ml/kg","mEq/kg/hr","g/kg","dose")
    private val concUnits    = listOf("mg/ml","IU/ml","mEq/ml","mg/tablet","g/tablet","dose/vial","ug/puff","ml")
    private val routeOptions = listOf("PO","IV","IM","SC","Topical","Buccal","IN","IM/IV","SC/IM","IV/IM/SC","Topical (eye)","SC implant","Other")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditDrugBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        repo = DrugRepository(this)
        editDrugId = intent.getStringExtra("drug_id")

        setupSpinners()

        if (editDrugId != null) {
            supportActionBar?.title = "Edit Drug"
            loadExistingDrug(editDrugId!!)
        } else {
            supportActionBar?.title = "Add Custom Drug"
        }

        binding.btnSave.setOnClickListener { saveDrug() }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> { finish(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupSpinners() {
        binding.spinnerAddCategory.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, ALL_CATEGORIES).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
        binding.spinnerDoseUnit.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, doseUnits).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
        binding.spinnerConcUnit.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, concUnits).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
        binding.spinnerRoute.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, routeOptions).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
    }

    private fun loadExistingDrug(id: String) {
        val drug = repo.getDrugById(id) ?: return
        binding.etAddName.setText(drug.name)
        binding.etAddSpecies.setText(drug.species.joinToString(", "))
        binding.etAddDoseMin.setText(drug.doseMin.toString())
        binding.etAddDoseMax.setText(drug.doseMax.toString())
        binding.etAddConcentration.setText(drug.concentration.toString())
        binding.etAddFrequency.setText(drug.frequency)
        binding.etAddNotes.setText(drug.notes)
        binding.etAddWarning.setText(drug.warning)
        binding.etMaxDose.setText(if (drug.maxDose > 0) drug.maxDose.toString() else "")

        setSpinner(binding.spinnerAddCategory, ALL_CATEGORIES, drug.category)
        setSpinner(binding.spinnerDoseUnit, doseUnits, drug.doseUnit)
        setSpinner(binding.spinnerConcUnit, concUnits, drug.concentrationUnit)
        setSpinner(binding.spinnerRoute, routeOptions, drug.route)
    }

    private fun setSpinner(spinner: android.widget.Spinner, options: List<String>, value: String) {
        val idx = options.indexOfFirst { it.equals(value, ignoreCase = true) }
        if (idx >= 0) spinner.setSelection(idx)
    }

    private fun saveDrug() {
        val name = binding.etAddName.text.toString().trim()
        if (name.isBlank()) { binding.etAddName.error = "Required"; return }

        val speciesList = binding.etAddSpecies.text.toString()
            .split(",").map { it.trim() }.filter { it.isNotBlank() }
        if (speciesList.isEmpty()) { binding.etAddSpecies.error = "Enter at least one species (Dog, Cat)"; return }

        val doseMin = binding.etAddDoseMin.text.toString().toDoubleOrNull()
        if (doseMin == null) { binding.etAddDoseMin.error = "Required"; return }
        val doseMax = binding.etAddDoseMax.text.toString().toDoubleOrNull() ?: doseMin
        val concentration = binding.etAddConcentration.text.toString().toDoubleOrNull() ?: 0.0
        val maxDose = binding.etMaxDose.text.toString().toDoubleOrNull() ?: 0.0

        val drug = Drug(
            id                = editDrugId ?: UUID.randomUUID().toString(),
            name              = name,
            category          = binding.spinnerAddCategory.selectedItem.toString(),
            species           = speciesList,
            doseMin           = doseMin,
            doseMax           = doseMax,
            doseUnit          = binding.spinnerDoseUnit.selectedItem.toString(),
            route             = binding.spinnerRoute.selectedItem.toString(),
            concentration     = concentration,
            concentrationUnit = binding.spinnerConcUnit.selectedItem.toString(),
            frequency         = binding.etAddFrequency.text.toString().trim(),
            notes             = binding.etAddNotes.text.toString().trim(),
            warning           = binding.etAddWarning.text.toString().trim(),
            maxDose           = maxDose,
            isCustom          = true
        )

        repo.saveCustomDrug(drug)
        Toast.makeText(this, "✓ Drug saved!", Toast.LENGTH_SHORT).show()
        finish()
    }
}
