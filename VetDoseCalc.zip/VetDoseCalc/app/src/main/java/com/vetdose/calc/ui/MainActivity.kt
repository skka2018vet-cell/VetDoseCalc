package com.vetdose.calc.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.vetdose.calc.R
import com.vetdose.calc.data.DrugRepository
import com.vetdose.calc.databinding.ActivityMainBinding
import com.vetdose.calc.model.ALL_CATEGORIES
import com.vetdose.calc.model.ALL_SPECIES

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repo: DrugRepository
    private lateinit var adapter: DrugListAdapter

    private var selectedSpecies = "All"
    private var selectedCategory = "All"
    private var searchQuery = ""
    private var patientWeight = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        repo = DrugRepository(this)

        setupSpinners()
        setupSearch()
        setupWeightInput()
        setupRecyclerView()
        updateDrugList()
    }

    override fun onResume() {
        super.onResume()
        updateDrugList()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_add_drug -> {
                startActivity(Intent(this, AddEditDrugActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupSpinners() {
        // Species spinner: All + Dog + Cat
        val speciesOptions = listOf("All") + ALL_SPECIES
        val speciesAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, speciesOptions)
        speciesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerSpecies.adapter = speciesAdapter
        binding.spinnerSpecies.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedSpecies = speciesOptions[pos]
                updateDrugList()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Category spinner
        val catOptions = listOf("All") + ALL_CATEGORIES
        val catAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, catOptions)
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCategory.adapter = catAdapter
        binding.spinnerCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selectedCategory = catOptions[pos]
                updateDrugList()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString() ?: ""
                updateDrugList()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupWeightInput() {
        binding.etWeight.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                patientWeight = s?.toString()?.toDoubleOrNull() ?: 0.0
                adapter.setWeight(patientWeight)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupRecyclerView() {
        adapter = DrugListAdapter(emptyList(), patientWeight) { drug ->
            val intent = Intent(this, DrugDetailActivity::class.java)
            intent.putExtra("drug_id", drug.id)
            intent.putExtra("weight", patientWeight)
            startActivity(intent)
        }
        binding.recyclerDrugs.layoutManager = LinearLayoutManager(this)
        binding.recyclerDrugs.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )
        binding.recyclerDrugs.adapter = adapter
    }

    private fun updateDrugList() {
        var drugs = if (searchQuery.isNotBlank()) {
            repo.searchDrugs(searchQuery)
        } else {
            repo.getAllDrugs()
        }

        if (selectedSpecies != "All") {
            drugs = drugs.filter { it.species.contains(selectedSpecies) }
        }
        if (selectedCategory != "All") {
            drugs = drugs.filter { it.category == selectedCategory }
        }

        adapter.updateList(drugs)
        val count = drugs.size
        binding.tvEmpty.visibility = if (count == 0) View.VISIBLE else View.GONE
        supportActionBar?.subtitle = "$count drugs"
    }
}
