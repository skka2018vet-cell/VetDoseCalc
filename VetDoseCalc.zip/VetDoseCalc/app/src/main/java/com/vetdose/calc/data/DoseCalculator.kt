package com.vetdose.calc.data

import com.vetdose.calc.model.DoseResult
import com.vetdose.calc.model.Drug
import kotlin.math.roundToInt

object DoseCalculator {

    /**
     * Calculate dose for a given drug and patient weight.
     * Handles mg/kg, ug/kg, IU/kg, ml/kg, and flat "dose" units.
     */
    fun calculate(drug: Drug, weightKg: Double): DoseResult {
        var doseMinRaw = drug.doseMin * weightKg
        var doseMaxRaw = drug.doseMax * weightKg

        // Apply absolute max dose cap if set
        val capped = drug.maxDose > 0 && (doseMinRaw > drug.maxDose || doseMaxRaw > drug.maxDose)
        if (drug.maxDose > 0) {
            if (doseMinRaw > drug.maxDose) doseMinRaw = drug.maxDose
            if (doseMaxRaw > drug.maxDose) doseMaxRaw = drug.maxDose
        }

        val concentration = drug.concentration

        val volumeMin: Double
        val volumeMax: Double

        when (drug.doseUnit.lowercase()) {
            "mg/kg" -> {
                // concentration in mg/ml → volume in ml
                volumeMin = if (concentration > 0) doseMinRaw / concentration else 0.0
                volumeMax = if (concentration > 0) doseMaxRaw / concentration else 0.0
            }
            "ug/kg" -> {
                // dose in µg, concentration in mg/ml → convert µg to mg first
                val doseMinMg = doseMinRaw / 1000.0
                val doseMaxMg = doseMaxRaw / 1000.0
                volumeMin = if (concentration > 0) doseMinMg / concentration else 0.0
                volumeMax = if (concentration > 0) doseMaxMg / concentration else 0.0
            }
            "iu/kg" -> {
                // concentration in IU/ml
                volumeMin = if (concentration > 0) doseMinRaw / concentration else 0.0
                volumeMax = if (concentration > 0) doseMaxRaw / concentration else 0.0
            }
            "ml/kg" -> {
                // dose IS the volume
                volumeMin = doseMinRaw
                volumeMax = doseMaxRaw
            }
            "meq/kg/hr" -> {
                // concentration in mEq/ml
                volumeMin = if (concentration > 0) doseMinRaw / concentration else 0.0
                volumeMax = if (concentration > 0) doseMaxRaw / concentration else 0.0
            }
            else -> {
                // "dose" (vaccines etc.) — flat
                volumeMin = doseMinRaw
                volumeMax = doseMaxRaw
            }
        }

        return DoseResult(
            drug = drug,
            weight = weightKg,
            species = "",
            doseMinMg = doseMinRaw,
            doseMaxMg = doseMaxRaw,
            volumeMin = volumeMin,
            volumeMax = volumeMax,
            isCapped = capped
        )
    }

    fun Double.fmt(decimals: Int = 2): String {
        val factor = Math.pow(10.0, decimals.toDouble())
        return (Math.round(this * factor).toDouble() / factor).toString()
    }
}
